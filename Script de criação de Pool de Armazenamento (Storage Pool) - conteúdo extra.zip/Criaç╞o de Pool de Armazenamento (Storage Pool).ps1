﻿#Script para criação do Pool de Armazenamento.

Get-Command -Module Storage | Select-Object Name # Lista de comandos que podem ser utilizados como módulo Storage.
Import-Module Storage # Importa o modulo Storage.
Get-PhysicalDisk -CanPool $true # Lista todos os discos físicos que são preparado para Pool de Armazenamento.
$s = Get-StorageSubSystem # Faz parte do comando de criação do Pool de Armazenamento.
New-StoragePool -StorageSubSystemId $s.UniqueId -FriendlyName LUN-1TB -PhysicalDisks (Get-PhysicalDisk -CanPool $true) # Criação do Pool de Aramzenamento, como o nome LUN-1TB.
Get-StoragePool # Informações do Pool de Armazenamento.
New-VirtualDisk -FriendlyName Datastore01 -StoragePoolFriendlyName LUN-1TB -ResiliencySettingName Mirror -Size 200GB # Criação de um disco virtual, como tamanho de 200 GB, utilizando o layout Mirror.
Get-VirtualDisk -FriendlyName "Datastore01" | Get-Disk # Verifica o número do disco virtual.
Initialize-Disk -Number 8 # Inicializa do disco vitual.
New-Partition -DiskNumber 8 -UseMaximumSize -AssignDriveLetter  # Abribui um letra ao disco, neste caso letra D:
Format-Volume -DriveLetter D -FileSystem NTFS -NewFileSystemLabel "DataStore01" # Cria o volume e formata no sistema de arquivos NTFS.
Format-Volume -DriveLetter D -FileSystem ReFS -NewFileSystemLabel "DataStore01" # Cria o volume e formata no sistema de arquivos ReFS.
# Pronto vocÊ já tem um Pool de Armazenamento, utilizando o layout Mirror, como 200 GB de espaço em disco, em um volume NTFS.